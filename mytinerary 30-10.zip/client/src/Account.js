import React, {Component} from 'react';



class Account extends Component {
    render() { return ( <div>
        
        <h1>Account Page</h1>
    </div>
);
}
}

export default Account;