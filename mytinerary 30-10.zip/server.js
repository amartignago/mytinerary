const express = require('express')
const app = express()
const mongoose = require("mongoose")
//aca me traigo la tabla//
const cors = require ("cors")

app.use(cors())
//app.get("/",(req,res) =>{
   // mongoose.connect('aca va el string que saco de atlas')
  // .then(()=>{
       //tabla
    //   .find({}).then(productFinded)=>{res.json(productFinded).status(204)})
       
   //})
//})
 

app.get('/', function (req, res) {
  res.send('Hello World')
})
 
app.listen(5000)

